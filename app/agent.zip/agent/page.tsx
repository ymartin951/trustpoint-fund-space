'use client';

import type { ReactNode } from 'react';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  BadgeCheck,
  CheckCircle2,
  Clock,
  Loader2,
  RefreshCw,
  Search,
  ShieldCheck,
  Store,
  UserPlus,
  Users,
  WalletCards,
} from 'lucide-react';

import { supabase } from '@/lib/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

type CustomerProfile = {
  id: string;
  full_name: string | null;
  phone: string | null;
  email?: string | null;
  country?: string | null;
  region?: string | null;
  city?: string | null;
  location?: string | null;
  occupation?: string | null;
  business_name?: string | null;
  business_type?: string | null;
  business_location?: string | null;
  user_category?: string | null;
  verification_status?: string | null;
  status?: string | null;
  trust_score?: number | null;
  created_at?: string | null;
};

type AgentCustomer = {
  relationship_id: string;
  id: string;
  agent_id: string;
  customer_id: string;
  relationship_status: string | null;
  notes: string | null;
  created_at: string | null;
  updated_at: string | null;
  profile: CustomerProfile | null;
};

type FundSpaceMember = {
  id: string;
  user_id: string;
  fund_space_id: string;
  status: string | null;
};

type AgentStats = {
  total: number;
  pending: number;
  verified: number;
  active: number;
  inFundSpace: number;
  notInFundSpace: number;
};

type QuickAction = {
  title: string;
  description: string;
  href: string;
  icon: ReactNode;
  buttonText: string;
  priority: 'high' | 'normal' | 'warning';
};

type StatusFilter =
  | 'ALL'
  | 'ACTIVE'
  | 'VERIFIED'
  | 'PENDING'
  | 'IN_FUND_SPACE'
  | 'NOT_IN_FUND_SPACE';

const statusTabs: { label: string; value: StatusFilter }[] = [
  { label: 'All', value: 'ALL' },
  { label: 'Active', value: 'ACTIVE' },
  { label: 'Verified', value: 'VERIFIED' },
  { label: 'Pending', value: 'PENDING' },
  { label: 'In Fund Space', value: 'IN_FUND_SPACE' },
  { label: 'Not Joined', value: 'NOT_IN_FUND_SPACE' },
];

function normalize(value: string | null | undefined) {
  return String(value || '').trim().toUpperCase();
}

function formatDate(dateString: string | null | undefined) {
  if (!dateString) return 'Not set';

  const date = new Date(dateString);

  if (Number.isNaN(date.getTime())) return 'Invalid date';

  return date.toLocaleDateString('en-GH', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function formatLabel(value: string | null | undefined) {
  if (!value) return 'Not set';

  return value
    .replaceAll('_', ' ')
    .toLowerCase()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function getStatusStyle(status: string | null | undefined) {
  const value = normalize(status || 'PENDING');

  if (['ACTIVE', 'VERIFIED', 'APPROVED', 'COMPLETED'].includes(value)) {
    return 'border-emerald-200 bg-emerald-50 text-emerald-700';
  }

  if (['PENDING', 'PENDING_VERIFICATION', 'UNDER_REVIEW'].includes(value)) {
    return 'border-amber-200 bg-amber-50 text-amber-700';
  }

  if (['REJECTED', 'INACTIVE', 'SUSPENDED', 'BLACKLISTED'].includes(value)) {
    return 'border-red-200 bg-red-50 text-red-700';
  }

  return 'border-slate-200 bg-slate-50 text-slate-700';
}

function getCustomerName(customer: AgentCustomer) {
  return customer.profile?.full_name || 'Unnamed customer';
}

function getCustomerInitial(customer: AgentCustomer) {
  return getCustomerName(customer).slice(0, 1).toUpperCase();
}

function getCustomerPhone(customer: AgentCustomer) {
  return customer.profile?.phone || 'No phone number';
}

function getCustomerLocation(customer: AgentCustomer) {
  const profile = customer.profile;

  if (!profile) return 'No location';

  const locationParts = [
    profile.location,
    profile.city,
    profile.region,
    profile.country,
  ].filter(Boolean);

  return locationParts.length > 0 ? locationParts.join(', ') : 'No location';
}

function getCustomerWork(customer: AgentCustomer) {
  const profile = customer.profile;

  if (!profile) return 'No occupation';

  return (
    profile.occupation ||
    profile.business_type ||
    profile.business_name ||
    'No occupation'
  );
}

function normalizeCustomerFromApi(item: any): AgentCustomer {
  const relationshipId = item.relationship_id || item.id;
  const customerId = item.customer_id || item.profile?.id || item.id;

  return {
    relationship_id: relationshipId,
    id: relationshipId,
    agent_id: item.agent_id,
    customer_id: customerId,
    relationship_status: item.relationship_status || item.status || 'ACTIVE',
    notes: item.notes || null,
    created_at: item.created_at || item.profile?.created_at || null,
    updated_at: item.updated_at || null,
    profile: item.profile || null,
  };
}

function SummaryItem({
  label,
  value,
  helper,
  onClick,
}: {
  label: string;
  value: string | number;
  helper?: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group min-w-0 rounded-2xl border border-white/15 bg-white/10 p-3 text-left transition hover:-translate-y-0.5 hover:bg-white/20 hover:shadow-lg"
    >
      <div className="flex min-w-0 items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[11px] font-black uppercase tracking-wide text-emerald-50/80">
            {label}
          </p>

          <p className="mt-1 truncate text-lg font-black text-white md:text-xl">
            {value}
          </p>

          {helper && (
            <p className="mt-1 truncate text-xs font-semibold text-emerald-50/70">
              {helper}
            </p>
          )}
        </div>

        <ArrowRight className="mt-1 h-4 w-4 shrink-0 text-emerald-50/70 transition group-hover:translate-x-1 group-hover:text-white" />
      </div>
    </button>
  );
}

function StatusPill({ status }: { status: string | null | undefined }) {
  return (
    <span
      className={`inline-flex max-w-full rounded-full border px-3 py-1 text-xs font-black ${getStatusStyle(
        status
      )}`}
    >
      <span className="truncate">{formatLabel(status)}</span>
    </span>
  );
}

function CompactInfo({
  label,
  value,
}: {
  label: string;
  value: string | number | null | undefined;
}) {
  return (
    <div className="min-w-0">
      <p className="truncate text-[11px] font-black uppercase tracking-wide text-slate-400">
        {label}
      </p>
      <p className="truncate text-sm font-black text-slate-900">
        {value ?? 'Not set'}
      </p>
    </div>
  );
}

function MessageBox({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-700">
      <div className="flex items-start gap-3">
        <AlertCircle className="mt-0.5 h-5 w-5 shrink-0" />
        <p className="min-w-0 break-words leading-6">{message}</p>
      </div>
    </div>
  );
}

function ActionRow({ action }: { action: QuickAction }) {
  const priorityClass =
    action.priority === 'high'
      ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
      : action.priority === 'warning'
        ? 'border-amber-200 bg-amber-50 text-amber-700'
        : 'border-slate-200 bg-slate-50 text-slate-700';

  return (
    <Link
      href={action.href}
      className="block overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-200 hover:shadow-md"
    >
      <div className="grid gap-4 p-4 xl:grid-cols-[1fr_auto] xl:items-center">
        <div className="min-w-0">
          <div className="flex items-start gap-3">
            <div
              className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border ${priorityClass}`}
            >
              {action.icon}
            </div>

            <div className="min-w-0">
              <h2 className="line-clamp-2 break-words text-base font-black leading-6 text-slate-900">
                {action.title}
              </h2>

              <p className="mt-1 line-clamp-2 break-words text-sm font-semibold leading-6 text-slate-500">
                {action.description}
              </p>
            </div>
          </div>
        </div>

        <div className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-emerald-700 px-4 text-sm font-black text-white hover:bg-emerald-800 xl:w-56">
          {action.buttonText}
          <ArrowRight className="h-4 w-4" />
        </div>
      </div>
    </Link>
  );
}

export default function AgentDashboardPage() {
  const { profile, loading } = useAuth();

  const [customers, setCustomers] = useState<AgentCustomer[]>([]);
  const [fundSpaceMembers, setFundSpaceMembers] = useState<FundSpaceMember[]>([]);
  const [pageLoading, setPageLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('ALL');

  useEffect(() => {
    if (loading) return;

    if (!profile?.id) {
      setPageLoading(false);
      setErrorMessage('Unable to identify your agent account. Please log in again.');
      return;
    }

    loadAgentDashboard();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, profile?.id]);

  const getAuthToken = async () => {
    const {
      data: { session },
      error,
    } = await supabase.auth.getSession();

    if (error || !session?.access_token) {
      throw new Error('Your session has expired. Please log in again.');
    }

    return session.access_token;
  };

  const loadAgentDashboard = async () => {
    try {
      setRefreshing(true);
      setErrorMessage('');

      const token = await getAuthToken();

      const response = await fetch('/api/agent/customers', {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const responseText = await response.text();
      const result = responseText ? JSON.parse(responseText) : null;

      if (!response.ok || !result?.success) {
        throw new Error(
          result?.message || 'Unable to load your agent customers.'
        );
      }

      const loadedCustomers = (result.customers || []).map(normalizeCustomerFromApi);

      setCustomers(loadedCustomers);

      const customerUserIds = loadedCustomers
        .map((customer: AgentCustomer) => customer.customer_id)
        .filter(Boolean);

      if (customerUserIds.length === 0) {
        setFundSpaceMembers([]);
        return;
      }

      const { data: memberData, error: memberError } = await supabase
        .from('fund_space_members')
        .select('id, user_id, fund_space_id, status')
        .in('user_id', customerUserIds);

      if (memberError) {
        console.warn('Agent Fund Space members warning:', memberError.message);
        setFundSpaceMembers([]);
        return;
      }

      setFundSpaceMembers((memberData || []) as FundSpaceMember[]);
    } catch (error: unknown) {
      console.error('Agent dashboard load error:', error);

      setErrorMessage(
        error instanceof Error
          ? error.message
          : 'Unable to load agent dashboard.'
      );
    } finally {
      setPageLoading(false);
      setRefreshing(false);
    }
  };

  const fundSpaceCustomerIds = useMemo(() => {
    return new Set(fundSpaceMembers.map((member) => member.user_id));
  }, [fundSpaceMembers]);

  const stats: AgentStats = useMemo(() => {
    const total = customers.length;

    const pending = customers.filter((customer) =>
      ['PENDING', 'PENDING_VERIFICATION', 'UNDER_REVIEW'].includes(
        normalize(customer.profile?.verification_status)
      )
    ).length;

    const verified = customers.filter((customer) =>
      ['VERIFIED', 'APPROVED'].includes(normalize(customer.profile?.verification_status))
    ).length;

    const active = customers.filter(
      (customer) =>
        normalize(customer.relationship_status) === 'ACTIVE' ||
        normalize(customer.profile?.status) === 'ACTIVE'
    ).length;

    const inFundSpace = customers.filter(
      (customer) =>
        customer.customer_id && fundSpaceCustomerIds.has(customer.customer_id)
    ).length;

    return {
      total,
      pending,
      verified,
      active,
      inFundSpace,
      notInFundSpace: Math.max(total - inFundSpace, 0),
    };
  }, [customers, fundSpaceCustomerIds]);

  const filteredCustomers = useMemo(() => {
    const searchValue = searchTerm.trim().toLowerCase();

    return customers.filter((customer) => {
      const profileData = customer.profile;
      const verificationStatus = normalize(profileData?.verification_status);
      const accountStatus = normalize(profileData?.status);
      const relationshipStatus = normalize(customer.relationship_status);
      const inFundSpace =
        customer.customer_id && fundSpaceCustomerIds.has(customer.customer_id);

      const matchesStatus =
        statusFilter === 'ALL' ||
        (statusFilter === 'ACTIVE' &&
          (relationshipStatus === 'ACTIVE' || accountStatus === 'ACTIVE')) ||
        (statusFilter === 'VERIFIED' &&
          ['VERIFIED', 'APPROVED'].includes(verificationStatus)) ||
        (statusFilter === 'PENDING' &&
          ['PENDING', 'PENDING_VERIFICATION', 'UNDER_REVIEW'].includes(
            verificationStatus
          )) ||
        (statusFilter === 'IN_FUND_SPACE' && Boolean(inFundSpace)) ||
        (statusFilter === 'NOT_IN_FUND_SPACE' && !inFundSpace);

      const haystack = [
        getCustomerName(customer),
        getCustomerPhone(customer),
        getCustomerLocation(customer),
        getCustomerWork(customer),
        profileData?.business_name,
        profileData?.business_type,
        profileData?.verification_status,
        profileData?.status,
        customer.relationship_status,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      const matchesSearch = !searchValue || haystack.includes(searchValue);

      return matchesStatus && matchesSearch;
    });
  }, [customers, fundSpaceCustomerIds, searchTerm, statusFilter]);

  const recentCustomers = useMemo(() => {
    return filteredCustomers.slice(0, 8);
  }, [filteredCustomers]);

  const quickActions: QuickAction[] = [
    {
      title: 'Register Customer',
      description:
        'Add a new customer with correct phone number, location, ID details, and profile information.',
      href: '/agent/register-customer',
      icon: <UserPlus className="h-5 w-5" />,
      buttonText: 'Register',
      priority: 'high',
    },
    {
      title: 'View Customers',
      description:
        'Open your full customer list, review customer details, verification status, and Fund Space status.',
      href: '/agent/customers',
      icon: <Users className="h-5 w-5" />,
      buttonText: 'Open Customers',
      priority: 'normal',
    },
    {
      title: 'Fund Space',
      description:
        'View Fund Space groups, contribution records, payment status, and customer participation.',
      href: '/dashboard/fund-space',
      icon: <WalletCards className="h-5 w-5" />,
      buttonText: 'Open Fund Space',
      priority: 'normal',
    },
  ];

  if (loading || pageLoading) {
    return (
      <main className="min-h-screen bg-slate-50 px-4 py-6">
        <div className="mx-auto flex min-h-[60vh] max-w-6xl items-center justify-center">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm">
            <Loader2 className="mx-auto h-10 w-10 animate-spin text-emerald-700" />
            <p className="mt-4 text-sm font-black text-slate-600">
              Loading agent dashboard...
            </p>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-5 md:px-8">
      <div className="mx-auto max-w-7xl space-y-5">
        <section className="overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-800 text-white shadow-sm">
          <div className="p-5 md:p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div className="min-w-0">
                <p className="inline-flex rounded-full bg-white/15 px-3 py-1 text-xs font-black">
                  Agent Control Center
                </p>

                <h1 className="mt-3 text-2xl font-black tracking-tight md:text-3xl">
                  Welcome, {profile?.full_name || 'TrustPoint Agent'}
                </h1>

                <p className="mt-2 max-w-2xl text-sm leading-6 text-emerald-50">
                  Click any summary item to filter your customers. Manage registration,
                  verification progress, and Fund Space participation from one simple page.
                </p>
              </div>

              <button
                type="button"
                onClick={loadAgentDashboard}
                disabled={refreshing}
                className="inline-flex min-h-11 w-fit items-center justify-center gap-2 rounded-2xl bg-white px-4 text-xs font-black text-emerald-700 hover:bg-emerald-50 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </button>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
              <SummaryItem
                label="Total Customers"
                value={stats.total}
                helper="All assigned"
                onClick={() => setStatusFilter('ALL')}
              />
              <SummaryItem
                label="Active"
                value={stats.active}
                helper="Active records"
                onClick={() => setStatusFilter('ACTIVE')}
              />
              <SummaryItem
                label="Verified"
                value={stats.verified}
                helper="Ready customers"
                onClick={() => setStatusFilter('VERIFIED')}
              />
              <SummaryItem
                label="Pending"
                value={stats.pending}
                helper="Needs review"
                onClick={() => setStatusFilter('PENDING')}
              />
              <SummaryItem
                label="In Fund Space"
                value={stats.inFundSpace}
                helper="Joined groups"
                onClick={() => setStatusFilter('IN_FUND_SPACE')}
              />
              <SummaryItem
                label="Not Joined"
                value={stats.notInFundSpace}
                helper="Can be guided"
                onClick={() => setStatusFilter('NOT_IN_FUND_SPACE')}
              />
            </div>
          </div>
        </section>

        {errorMessage && <MessageBox message={errorMessage} />}

        <section className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="grid gap-3 lg:grid-cols-[1fr_auto] lg:items-center">
            <div className="relative min-w-0">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search name, phone, location, work, status..."
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                className="min-h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 pl-11 pr-4 text-sm font-semibold outline-none focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            <div className="flex gap-2 overflow-x-auto pb-1">
              {statusTabs.map((tab) => (
                <button
                  key={tab.value}
                  type="button"
                  onClick={() => setStatusFilter(tab.value)}
                  className={`shrink-0 rounded-2xl px-4 py-3 text-xs font-black transition ${
                    statusFilter === tab.value
                      ? 'bg-emerald-700 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <p className="mt-3 text-xs font-bold text-slate-500">
            Showing {recentCustomers.length} of {filteredCustomers.length} matching customers.
          </p>
        </section>

        <section className="space-y-3">
          {recentCustomers.length === 0 ? (
            <div className="rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm">
              <Store className="mx-auto h-10 w-10 text-slate-300" />
              <h2 className="mt-4 text-lg font-black text-slate-900">
                No customers found
              </h2>
              <p className="mt-2 text-sm text-slate-500">
                Try another filter or register a new customer.
              </p>

              <Link
                href="/agent/register-customer"
                className="mt-5 inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-emerald-700 px-4 text-sm font-black text-white hover:bg-emerald-800"
              >
                Register Customer
                <UserPlus className="h-4 w-4" />
              </Link>
            </div>
          ) : (
            recentCustomers.map((customer) => {
              const name = getCustomerName(customer);
              const phone = getCustomerPhone(customer);
              const location = getCustomerLocation(customer);
              const work = getCustomerWork(customer);
              const verificationStatus = customer.profile?.verification_status || 'PENDING';
              const relationshipStatus =
                customer.relationship_status || customer.profile?.status || 'ACTIVE';
              const inFundSpace =
                customer.customer_id && fundSpaceCustomerIds.has(customer.customer_id);

              return (
                <article
                  key={customer.relationship_id}
                  className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:border-emerald-200 hover:shadow-md"
                >
                  <div className="grid gap-4 p-4 xl:grid-cols-[1fr_auto] xl:items-center">
                    <div className="min-w-0">
                      <div className="flex flex-wrap gap-2">
                        <StatusPill status={verificationStatus} />
                        <StatusPill status={relationshipStatus} />
                        <StatusPill status={inFundSpace ? 'IN_FUND_SPACE' : 'NOT_JOINED'} />
                      </div>

                      <div className="mt-3 flex items-start gap-3">
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-emerald-50 text-sm font-black text-emerald-700">
                          {getCustomerInitial(customer)}
                        </div>

                        <div className="min-w-0">
                          <h2 className="line-clamp-2 break-words text-base font-black leading-6 text-slate-900">
                            {name}
                          </h2>

                          <p className="mt-1 truncate text-sm font-semibold text-slate-500">
                            {phone} · {location}
                          </p>
                        </div>
                      </div>

                      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                        <CompactInfo label="Work / Business" value={work} />
                        <CompactInfo
                          label="Registered"
                          value={formatDate(customer.created_at)}
                        />
                        <CompactInfo
                          label="Trust Score"
                          value={
                            typeof customer.profile?.trust_score === 'number'
                              ? `${customer.profile.trust_score}%`
                              : 'Not scored'
                          }
                        />
                        <CompactInfo
                          label="Fund Space"
                          value={inFundSpace ? 'Joined' : 'Not joined'}
                        />
                      </div>
                    </div>

                    <div className="grid gap-2 sm:grid-cols-2 xl:w-64 xl:grid-cols-1">
                      <Link
                        href={`/agent/customers/${customer.customer_id}`}
                        className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-emerald-700 px-4 text-sm font-black text-white hover:bg-emerald-800"
                      >
                        View Details
                        <ArrowRight className="h-4 w-4" />
                      </Link>

                      <Link
                        href="/dashboard/fund-space"
                        className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 hover:bg-slate-50"
                      >
                        <WalletCards className="h-4 w-4" />
                        Fund Space
                      </Link>
                    </div>
                  </div>
                </article>
              );
            })
          )}

          {filteredCustomers.length > recentCustomers.length && (
            <div className="rounded-3xl border border-emerald-100 bg-emerald-50 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-sm font-bold text-emerald-800">
                  Showing the first {recentCustomers.length} customers. Open the full list to see all{' '}
                  {filteredCustomers.length}.
                </p>

                <Link
                  href="/agent/customers"
                  className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-emerald-700 px-4 text-sm font-black text-white hover:bg-emerald-800"
                >
                  View All Customers
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          )}
        </section>

        <section className="space-y-3">
          <div>
            <h2 className="text-lg font-black text-slate-900">
              Agent Actions
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              These rows are clickable. Tap any row to continue your work.
            </p>
          </div>

          {quickActions.map((action) => (
            <ActionRow key={action.href} action={action} />
          ))}
        </section>

        <section className="rounded-3xl border border-amber-100 bg-amber-50 p-5">
          <div className="flex items-start gap-3">
            <ShieldCheck className="mt-1 h-5 w-5 shrink-0 text-amber-700" />

            <div className="min-w-0">
              <h2 className="text-base font-black text-amber-900">
                Agent Responsibility Reminder
              </h2>

              <p className="mt-2 break-words text-sm font-semibold leading-6 text-amber-700">
                Register only real customers with correct names, phone numbers, location,
                and payment details. Accurate records protect customer trust, verification,
                contributions, payouts, and withdrawals.
              </p>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}