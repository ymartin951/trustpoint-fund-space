'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import {
  AlertCircle,
  ArrowLeft,
  CalendarClock,
  CheckCircle2,
  CircleDollarSign,
  Clock,
  HandCoins,
  Loader2,
  Phone,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  TimerReset,
  UserRound,
  Users,
  Wallet,
} from 'lucide-react';

import ManualMerchantPaymentModal from '@/components/fund-space/ManualMerchantPaymentModal';
import { supabase } from '@/lib/supabase/client';

type CurrentProfile = {
  id: string;
  full_name: string | null;
  phone: string | null;
  email: string | null;
  role: string | null;
  status: string | null;
  verification_status: string | null;
  is_blacklisted?: boolean | null;
};

type FundSpace = {
  id: string;
  name: string | null;
  contribution_amount: number | null;
  status: string | null;
  member_limit?: number | null;
  current_round_number?: number | null;
  frequency?: string | null;
  start_date?: string | null;
  completed_at?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
};

type FundSpaceMember = {
  id: string;
  user_id: string;
  fund_space_id: string;
  contribution_amount: number | null;
  status: string | null;
  joined_at: string | null;
  joined_by_agent: string | null;
  has_received_payout?: boolean | null;
  payout_order?: number | null;
  position_number?: number | null;
  received_round_number?: number | null;
};

type ProfileSummary = {
  id: string;
  full_name: string | null;
  phone: string | null;
  email: string | null;
  role: string | null;
  status: string | null;
  verification_status: string | null;
  registered_by_agent?: string | null;
};

type Round = {
  id: string;
  fund_space_id: string;
  round_number: number;
  recipient_user_id?: string | null;
  contribution_deadline?: string | null;
  due_date?: string | null;
  week_start_date?: string | null;
  week_end_date?: string | null;
  payout_date?: string | null;
  status: string | null;
  created_at?: string | null;
};

type Contribution = {
  id: string;
  fund_space_id: string;
  round_id: string;
  user_id: string;
  amount_due: number;
  amount_paid: number;
  status: string;
  payment_method: string | null;
  payment_reference: string | null;
  paid_at: string | null;
  confirmed_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  payment_timing?: string | null;
  is_late?: boolean | null;
  late_fee_amount?: number | null;
  late_fee_status?: string | null;
  late_fee_paid_at?: string | null;
  late_fee_waived_at?: string | null;
  late_fee_waiver_reason?: string | null;
};

type Payout = {
  id: string;
  fund_space_id: string;
  round_id: string;
  recipient_user_id: string | null;
  gross_amount?: number | null;
  platform_fee?: number | null;
  net_amount?: number | null;
  status: string | null;
  approved_at?: string | null;
  paid_at?: string | null;
  created_at?: string | null;
};

type AgentCustomer = {
  id: string;
  agent_id: string;
  customer_id: string;
  relationship_status: string | null;
};

type MemberWithProfile = FundSpaceMember & {
  profile: ProfileSummary | null;
  contributions: Contribution[];
  payouts: Payout[];
  is_visible_to_agent: boolean;
  relationship_label: string;
};

function isValidUuid(value: string | null | undefined) {
  if (!value) return false;

  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    value
  );
}

function normalizeRole(role: string | null | undefined) {
  return String(role || '').toUpperCase();
}

function isAllowedRole(role: string | null | undefined) {
  const value = normalizeRole(role);
  return value === 'AGENT' || value === 'ADMIN' || value === 'SUPER_ADMIN';
}

function isAdminRole(role: string | null | undefined) {
  const value = normalizeRole(role);
  return value === 'ADMIN' || value === 'SUPER_ADMIN';
}

function formatCurrency(amount: number | string | null | undefined) {
  return `GH₵${Number(amount || 0).toLocaleString('en-GH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function formatDate(value: string | null | undefined) {
  if (!value) return 'Not set';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Invalid date';

  return date.toLocaleDateString('en-GH', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function formatDateTime(value: string | null | undefined) {
  if (!value) return 'Not set';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Invalid date';

  return date.toLocaleString('en-GH', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatLabel(value: string | null | undefined) {
  if (!value) return 'Not set';

  return value
    .replaceAll('_', ' ')
    .toLowerCase()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function getStatusStyle(status: string | null | undefined) {
  const value = String(status || '').toUpperCase();

  if (
    [
      'ACTIVE',
      'PAID',
      'ON_TIME',
      'APPROVED',
      'VERIFIED',
      'COMPLETED',
      'SUCCESS',
      'PAID_OUT',
      'WAIVED',
    ].includes(value)
  ) {
    return 'border-emerald-200 bg-emerald-50 text-emerald-700';
  }

  if (
    [
      'PENDING',
      'PENDING_REVIEW',
      'PARTIALLY_PAID',
      'FORMING',
      'APPLIED',
      'COLLECTING',
      'READY_FOR_PAYOUT',
      'READY_FOR_ADMIN_APPROVAL',
      'PENDING_ADMIN_APPROVAL',
    ].includes(value)
  ) {
    return 'border-amber-200 bg-amber-50 text-amber-700';
  }

  if (
    [
      'LATE',
      'MISSED',
      'REJECTED',
      'FAILED',
      'CANCELLED',
      'DEFAULTED',
      'SUSPENDED',
      'REMOVED',
    ].includes(value)
  ) {
    return 'border-red-200 bg-red-50 text-red-700';
  }

  if (value === 'PAUSED') {
    return 'border-purple-200 bg-purple-50 text-purple-700';
  }

  return 'border-slate-200 bg-slate-50 text-slate-700';
}

function getMemberOrder(member: MemberWithProfile) {
  return Number(member.payout_order || member.position_number || 999999);
}

function getRoundDeadline(round: Round | null | undefined) {
  return round?.contribution_deadline || round?.due_date || null;
}

function getContributionForRound(
  member: MemberWithProfile,
  roundId: string | null
) {
  if (!roundId) return null;
  return member.contributions.find((item) => item.round_id === roundId) || null;
}

function canSubmitPayment(contribution: Contribution | null | undefined) {
  if (!contribution) return false;

  const status = String(contribution.status || '').toUpperCase();
  return ['PENDING', 'PARTIALLY_PAID', 'LATE', 'MISSED'].includes(status);
}

function StatusPill({ status }: { status: string | null | undefined }) {
  return (
    <span
      className={`inline-flex w-fit items-center rounded-full border px-3 py-1 text-xs font-black ${getStatusStyle(
        status
      )}`}
    >
      {formatLabel(status)}
    </span>
  );
}

function SummaryCard({
  title,
  value,
  helper,
  icon,
}: {
  title: string;
  value: string | number;
  helper: string;
  icon: ReactNode;
}) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-4 inline-flex rounded-2xl bg-emerald-50 p-3 text-emerald-700">
        {icon}
      </div>

      <p className="text-sm font-bold text-slate-500">{title}</p>
      <p className="mt-1 text-2xl font-black text-slate-900">{value}</p>
      <p className="mt-1 text-xs leading-5 text-slate-500">{helper}</p>
    </div>
  );
}

function DetailBox({
  label,
  value,
}: {
  label: string;
  value: string | number | null | undefined;
}) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
      <p className="text-xs font-black uppercase tracking-wide text-slate-400">
        {label}
      </p>
      <p className="mt-1 break-words text-sm font-bold text-slate-900">
        {value ?? 'Not provided'}
      </p>
    </div>
  );
}

function EmptyBlock({ message }: { message: string }) {
  return (
    <div className="rounded-3xl border border-dashed border-slate-200 bg-white p-8 text-center">
      <Users className="mx-auto mb-3 h-10 w-10 text-slate-300" />
      <p className="text-sm font-bold text-slate-500">{message}</p>
    </div>
  );
}

export default function AgentFundSpaceDetailsPage() {
  const params = useParams();

  const routeId = useMemo(() => {
    const possibleValues = [
      params?.id,
      params?.fundSpaceId,
      params?.fund_space_id,
      params?.customerId,
      params?.customer_id,
      params?.slug,
    ];

    for (const value of possibleValues) {
      if (Array.isArray(value) && typeof value[0] === 'string') {
        return decodeURIComponent(value[0]).trim();
      }

      if (typeof value === 'string') {
        return decodeURIComponent(value).trim();
      }
    }

    const firstStringValue = Object.values(params || {}).find((value) => {
      return typeof value === 'string' || Array.isArray(value);
    });

    if (Array.isArray(firstStringValue)) {
      return decodeURIComponent(String(firstStringValue[0] || '')).trim();
    }

    return decodeURIComponent(String(firstStringValue || '')).trim();
  }, [params]);

  const [currentProfile, setCurrentProfile] = useState<CurrentProfile | null>(
    null
  );
  const [fundSpace, setFundSpace] = useState<FundSpace | null>(null);
  const [resolvedFundSpaceId, setResolvedFundSpaceId] = useState('');
  const [members, setMembers] = useState<MemberWithProfile[]>([]);
  const [rounds, setRounds] = useState<Round[]>([]);
  const [selectedRoundId, setSelectedRoundId] = useState('');

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedContribution, setSelectedContribution] =
    useState<Contribution | null>(null);
  const [selectedCustomerName, setSelectedCustomerName] = useState('');

  const selectedRound = useMemo(() => {
    if (!selectedRoundId) return rounds[0] || null;
    return rounds.find((round) => round.id === selectedRoundId) || null;
  }, [rounds, selectedRoundId]);

  const visibleMembers = useMemo(() => {
    if (!currentProfile) return [];
    if (isAdminRole(currentProfile.role)) return members;
    return members.filter((member) => member.is_visible_to_agent);
  }, [currentProfile, members]);

  const currentRecipient = useMemo(() => {
    if (!selectedRound?.recipient_user_id) return null;

    return (
      members.find(
        (member) => member.user_id === selectedRound.recipient_user_id
      ) || null
    );
  }, [members, selectedRound?.recipient_user_id]);

  const stats = useMemo(() => {
    const currentRoundId = selectedRound?.id || null;

    const roundContributions = visibleMembers
      .map((member) => getContributionForRound(member, currentRoundId))
      .filter(Boolean) as Contribution[];

    const paid = roundContributions.filter(
      (item) => String(item.status || '').toUpperCase() === 'PAID'
    );

    const pending = roundContributions.filter((item) =>
      ['PENDING', 'PARTIALLY_PAID'].includes(
        String(item.status || '').toUpperCase()
      )
    );

    const late = roundContributions.filter(
      (item) => String(item.payment_timing || '').toUpperCase() === 'LATE'
    );

    const missed = roundContributions.filter(
      (item) => String(item.status || '').toUpperCase() === 'MISSED'
    );

    return {
      members: visibleMembers.length,
      paid: paid.length,
      pending: pending.length,
      late: late.length,
      missed: missed.length,
      collectedAmount: paid.reduce(
        (sum, item) => sum + Number(item.amount_paid || 0),
        0
      ),
      expectedAmount: visibleMembers.reduce((sum, member) => {
        const contribution = getContributionForRound(member, currentRoundId);

        return (
          sum +
          Number(
            contribution?.amount_due ||
              member.contribution_amount ||
              fundSpace?.contribution_amount ||
              0
          )
        );
      }, 0),
    };
  }, [fundSpace?.contribution_amount, selectedRound?.id, visibleMembers]);

  const loadPage = useCallback(
    async (showRefresh = false) => {
      try {
        if (showRefresh) {
          setRefreshing(true);
        } else {
          setLoading(true);
        }

        setErrorMessage('');
        setSuccessMessage('');

        if (!isValidUuid(routeId)) {
          throw new Error(`Invalid ID in URL: ${routeId || 'missing'}`);
        }

        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession();

        if (sessionError || !session?.user) {
          throw new Error('Your session has expired. Please login again.');
        }

        const { data: profileData, error: profileError } = await supabase
          .from('profiles')
          .select(
            'id, full_name, phone, email, role, status, verification_status, is_blacklisted'
          )
          .eq('id', session.user.id)
          .maybeSingle();

        if (profileError) throw profileError;

        if (!profileData) {
          throw new Error('Profile could not be found.');
        }

        const profile = profileData as CurrentProfile;

        if (!isAllowedRole(profile.role)) {
          throw new Error('You do not have permission to view this Fund Space.');
        }

        if (String(profile.status || '').toUpperCase() !== 'ACTIVE') {
          throw new Error('Your account must be active to view this Fund Space.');
        }

        if (profile.is_blacklisted) {
          throw new Error('This account cannot view Fund Space groups.');
        }

        let finalFundSpaceId = routeId;

        let { data: fundSpaceData, error: fundSpaceError } = await supabase
          .from('fund_spaces')
          .select('*')
          .eq('id', finalFundSpaceId)
          .maybeSingle();

        if (fundSpaceError) throw fundSpaceError;

        if (!fundSpaceData) {
          const { data: customerMembership, error: membershipLookupError } =
            await supabase
              .from('fund_space_members')
              .select('fund_space_id, user_id, status, joined_at')
              .eq('user_id', routeId)
              .order('joined_at', { ascending: false })
              .limit(1)
              .maybeSingle();

          if (membershipLookupError) throw membershipLookupError;

          if (!customerMembership?.fund_space_id) {
            throw new Error(
              'Unable to load Fund Space details. The ID in the URL is not a Fund Space ID, and no Fund Space membership was found for this customer.'
            );
          }

          finalFundSpaceId = customerMembership.fund_space_id;

          const retryResult = await supabase
            .from('fund_spaces')
            .select('*')
            .eq('id', finalFundSpaceId)
            .maybeSingle();

          if (retryResult.error) throw retryResult.error;

          fundSpaceData = retryResult.data;
        }

        if (!fundSpaceData) {
          throw new Error('Unable to load Fund Space details.');
        }

        const loadedFundSpace = fundSpaceData as FundSpace;

        const { data: roundData, error: roundError } = await supabase
          .from('fund_space_rounds')
          .select('*')
          .eq('fund_space_id', finalFundSpaceId)
          .order('round_number', { ascending: true });

        if (roundError) throw roundError;

        const loadedRounds = (roundData || []) as Round[];

        const { data: memberData, error: memberError } = await supabase
          .from('fund_space_members')
          .select('*')
          .eq('fund_space_id', finalFundSpaceId)
          .order('position_number', { ascending: true });

        if (memberError) throw memberError;

        const loadedMembers = (memberData || []) as FundSpaceMember[];
        const memberUserIds = loadedMembers
          .map((member) => member.user_id)
          .filter(Boolean);

        const { data: profileRows, error: memberProfilesError } =
          memberUserIds.length > 0
            ? await supabase
                .from('profiles')
                .select(
                  'id, full_name, phone, email, role, status, verification_status, registered_by_agent'
                )
                .in('id', memberUserIds)
            : { data: [], error: null };

        if (memberProfilesError) throw memberProfilesError;

        const { data: contributionRows, error: contributionError } =
          memberUserIds.length > 0
            ? await supabase
                .from('fund_space_contributions')
                .select('*')
                .eq('fund_space_id', finalFundSpaceId)
                .in('user_id', memberUserIds)
                .order('created_at', { ascending: false })
            : { data: [], error: null };

        if (contributionError) throw contributionError;

        const { data: payoutRows, error: payoutError } =
          memberUserIds.length > 0
            ? await supabase
                .from('fund_space_payouts')
                .select('*')
                .eq('fund_space_id', finalFundSpaceId)
                .in('recipient_user_id', memberUserIds)
                .order('created_at', { ascending: false })
            : { data: [], error: null };

        if (payoutError) throw payoutError;

        let agentCustomers: AgentCustomer[] = [];

        if (normalizeRole(profile.role) === 'AGENT' && memberUserIds.length > 0) {
          const { data: agentCustomerRows, error: agentCustomerError } =
            await supabase
              .from('agent_customers')
              .select('id, agent_id, customer_id, relationship_status')
              .eq('agent_id', profile.id)
              .in('customer_id', memberUserIds);

          if (agentCustomerError) throw agentCustomerError;

          agentCustomers = (agentCustomerRows || []) as AgentCustomer[];
        }

        const profileMap = new Map(
          ((profileRows || []) as ProfileSummary[]).map((item) => [
            item.id,
            item,
          ])
        );

        const contributionMap = new Map<string, Contribution[]>();

        ((contributionRows || []) as Contribution[]).forEach((contribution) => {
          const current = contributionMap.get(contribution.user_id) || [];
          current.push(contribution);
          contributionMap.set(contribution.user_id, current);
        });

        const payoutMap = new Map<string, Payout[]>();

        ((payoutRows || []) as Payout[]).forEach((payout) => {
          const recipientId = payout.recipient_user_id || '';
          const current = payoutMap.get(recipientId) || [];
          current.push(payout);
          payoutMap.set(recipientId, current);
        });

        const activeAgentCustomerIds = new Set(
          agentCustomers
            .filter((item) =>
              ['ACTIVE', 'APPROVED', 'VERIFIED'].includes(
                String(item.relationship_status || '').toUpperCase()
              )
            )
            .map((item) => item.customer_id)
        );

        const mappedMembers: MemberWithProfile[] = loadedMembers.map(
          (member) => {
            const memberProfile = profileMap.get(member.user_id) || null;

            const isSelf = member.user_id === profile.id;
            const joinedByThisAgent = member.joined_by_agent === profile.id;
            const registeredByThisAgent =
              memberProfile?.registered_by_agent === profile.id ||
              activeAgentCustomerIds.has(member.user_id);

            const isVisibleToAgent =
              isAdminRole(profile.role) ||
              isSelf ||
              joinedByThisAgent ||
              registeredByThisAgent;

            let relationshipLabel = 'Group member';

            if (isSelf) {
              relationshipLabel = 'You';
            } else if (joinedByThisAgent || registeredByThisAgent) {
              relationshipLabel = 'Your customer';
            }

            return {
              ...member,
              profile: memberProfile,
              contributions: contributionMap.get(member.user_id) || [],
              payouts: payoutMap.get(member.user_id) || [],
              is_visible_to_agent: isVisibleToAgent,
              relationship_label: relationshipLabel,
            };
          }
        );

        if (normalizeRole(profile.role) === 'AGENT') {
          const canViewFundSpace = mappedMembers.some(
            (member) => member.is_visible_to_agent
          );

          if (!canViewFundSpace) {
            throw new Error(
              'You can only view Fund Spaces that include you or customers registered under you.'
            );
          }
        }

        setCurrentProfile(profile);
        setFundSpace(loadedFundSpace);
        setResolvedFundSpaceId(finalFundSpaceId);
        setRounds(loadedRounds);
        setMembers(mappedMembers);

        setSelectedRoundId((current) => {
          if (current && loadedRounds.some((round) => round.id === current)) {
            return current;
          }

          const currentRound =
            loadedRounds.find(
              (round) =>
                round.round_number === loadedFundSpace.current_round_number
            ) ||
            loadedRounds.find(
              (round) => String(round.status || '').toUpperCase() === 'ACTIVE'
            ) ||
            loadedRounds[loadedRounds.length - 1] ||
            loadedRounds[0];

          return currentRound?.id || '';
        });
      } catch (error) {
        console.error('Agent Fund Space details load error:', error);

        setErrorMessage(
          error instanceof Error
            ? error.message
            : 'Unable to load Fund Space details.'
        );

        setCurrentProfile(null);
        setFundSpace(null);
        setResolvedFundSpaceId('');
        setMembers([]);
        setRounds([]);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [routeId]
  );

  useEffect(() => {
    loadPage();
  }, [loadPage]);

  function openPaymentModal(
    member: MemberWithProfile,
    contribution: Contribution
  ) {
    setSelectedContribution(contribution);
    setSelectedCustomerName(member.profile?.full_name || 'Customer');
    setPaymentModalOpen(true);
    setErrorMessage('');
    setSuccessMessage('');
  }

  async function handleSubmittedPayment() {
    setSuccessMessage('Payment submitted successfully. Admin will review it.');
    await loadPage(true);
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-slate-50 px-4 py-6 md:px-8">
        <div className="mx-auto flex min-h-[60vh] max-w-7xl items-center justify-center">
          <div className="text-center">
            <Loader2 className="mx-auto mb-4 h-10 w-10 animate-spin text-emerald-700" />
            <h1 className="text-lg font-black text-slate-900">
              Loading Fund Space details...
            </h1>
            <p className="mt-2 text-sm text-slate-500">
              Please wait while TrustPoint loads the group information.
            </p>
          </div>
        </div>
      </main>
    );
  }

  if (errorMessage && !fundSpace) {
    return (
      <main className="min-h-screen bg-slate-50 px-4 py-6 md:px-8">
        <div className="mx-auto max-w-3xl">
          <Link
            href="/agent"
            className="mb-5 inline-flex min-h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 hover:bg-slate-50"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Agent Dashboard
          </Link>

          <section className="rounded-3xl border border-red-200 bg-red-50 p-6 text-red-700 shadow-sm">
            <div className="flex items-start gap-3">
              <AlertCircle className="mt-1 h-6 w-6 shrink-0" />
              <div>
                <h1 className="text-xl font-black">Could not load details</h1>
                <p className="mt-2 text-sm font-bold leading-6">
                  {errorMessage}
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-6 md:px-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <section className="rounded-3xl bg-gradient-to-br from-emerald-800 via-emerald-700 to-teal-700 p-6 text-white shadow-sm md:p-8">
          <div className="flex flex-col gap-6 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <Link
                href="/agent"
                className="mb-5 inline-flex min-h-10 items-center gap-2 rounded-2xl bg-white/15 px-4 text-sm font-black text-white ring-1 ring-white/20 hover:bg-white/20"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Agent Dashboard
              </Link>

              <p className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-xs font-black">
                <Users className="h-4 w-4" />
                Agent Fund Space View
              </p>

              <h1 className="text-3xl font-black tracking-tight md:text-4xl">
                {fundSpace?.name || 'Fund Space Details'}
              </h1>

              <p className="mt-3 max-w-3xl text-sm leading-7 text-emerald-50">
                View your Fund Space customers, weekly contribution status,
                payout order, current round, late fee status, and payment
                actions.
              </p>

              <div className="mt-5 flex flex-wrap gap-2">
                <StatusPill status={fundSpace?.status} />
                <span className="rounded-full border border-white/20 bg-white/15 px-3 py-1 text-xs font-black text-white">
                  {formatCurrency(fundSpace?.contribution_amount)} weekly
                </span>
                <span className="rounded-full border border-white/20 bg-white/15 px-3 py-1 text-xs font-black text-white">
                  Round{' '}
                  {selectedRound?.round_number ||
                    fundSpace?.current_round_number ||
                    'N/A'}
                </span>
              </div>

              {resolvedFundSpaceId && resolvedFundSpaceId !== routeId && (
                <p className="mt-3 text-xs font-semibold text-emerald-50">
                  Loaded from customer link. Resolved Fund Space ID:{' '}
                  {resolvedFundSpaceId}
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={() => loadPage(true)}
              disabled={refreshing}
              className="inline-flex min-h-11 w-fit items-center justify-center gap-2 rounded-2xl bg-white px-4 text-sm font-black text-emerald-700 hover:bg-emerald-50 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {refreshing ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              Refresh
            </button>
          </div>
        </section>

        {successMessage && (
          <div className="rounded-3xl border border-emerald-200 bg-emerald-50 p-5 text-emerald-700">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" />
              <p className="text-sm font-bold leading-6">{successMessage}</p>
            </div>
          </div>
        )}

        {errorMessage && fundSpace && (
          <div className="rounded-3xl border border-red-200 bg-red-50 p-5 text-red-700">
            <div className="flex items-start gap-3">
              <AlertCircle className="mt-0.5 h-5 w-5 shrink-0" />
              <p className="text-sm font-bold leading-6">{errorMessage}</p>
            </div>
          </div>
        )}

        <section className="grid gap-5 md:grid-cols-2 xl:grid-cols-5">
          <SummaryCard
            title="Visible Members"
            value={stats.members}
            helper="You and customers linked to you"
            icon={<Users className="h-6 w-6" />}
          />

          <SummaryCard
            title="Paid"
            value={stats.paid}
            helper="Paid in selected round"
            icon={<CheckCircle2 className="h-6 w-6" />}
          />

          <SummaryCard
            title="Pending"
            value={stats.pending}
            helper="Not fully paid yet"
            icon={<Clock className="h-6 w-6" />}
          />

          <SummaryCard
            title="Late / Missed"
            value={`${stats.late}/${stats.missed}`}
            helper="Late payments and missed payments"
            icon={<TimerReset className="h-6 w-6" />}
          />

          <SummaryCard
            title="Collected"
            value={formatCurrency(stats.collectedAmount)}
            helper={`Expected ${formatCurrency(stats.expectedAmount)}`}
            icon={<Wallet className="h-6 w-6" />}
          />
        </section>

        <section className="grid gap-5 lg:grid-cols-[1fr_360px]">
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-4 flex items-start gap-3">
              <div className="rounded-2xl bg-emerald-50 p-3 text-emerald-700">
                <CalendarClock className="h-6 w-6" />
              </div>

              <div>
                <h2 className="text-lg font-black text-slate-900">
                  Round Selector
                </h2>
                <p className="mt-1 text-sm leading-6 text-slate-500">
                  Choose a round to see contribution status for that week.
                </p>
              </div>
            </div>

            <select
              value={selectedRoundId}
              onChange={(event) => setSelectedRoundId(event.target.value)}
              className="min-h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm font-bold text-slate-700 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
            >
              {rounds.length === 0 && <option value="">No rounds found</option>}

              {rounds.map((round) => (
                <option key={round.id} value={round.id}>
                  Round {round.round_number} • {formatLabel(round.status)} •
                  Deadline {formatDate(getRoundDeadline(round))}
                </option>
              ))}
            </select>
          </div>

          <div className="rounded-3xl border border-amber-200 bg-amber-50 p-5 text-amber-800 shadow-sm">
            <div className="flex items-start gap-3">
              <ShieldCheck className="mt-1 h-5 w-5 shrink-0" />
              <div>
                <h2 className="font-black">Agent visibility rule</h2>
                <p className="mt-2 text-sm font-semibold leading-6">
                  Agents only see themselves and customers registered under
                  them. Admins and super admins can see all group members.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm md:p-6">
          <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-black text-slate-900">
                Members & Contributions
              </h2>
              <p className="mt-1 text-sm leading-6 text-slate-500">
                Contribution status for Round{' '}
                {selectedRound?.round_number || 'N/A'}.
              </p>
            </div>

            <StatusPill status={selectedRound?.status} />
          </div>

          {visibleMembers.length === 0 ? (
            <EmptyBlock message="No visible members found for your agent account." />
          ) : (
            <div className="space-y-4">
              {[...visibleMembers]
                .sort((a, b) => getMemberOrder(a) - getMemberOrder(b))
                .map((member) => {
                  const contribution = getContributionForRound(
                    member,
                    selectedRound?.id || null
                  );

                  const lateFeeAmount = Number(
                    contribution?.late_fee_amount || 0
                  );
                  const canPay = canSubmitPayment(contribution);

                  return (
                    <article
                      key={member.id}
                      className="rounded-3xl border border-slate-200 bg-slate-50 p-4 md:p-5"
                    >
                      <div className="grid gap-5 xl:grid-cols-[1fr_300px]">
                        <div>
                          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                            <div>
                              <p className="mb-2 inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-xs font-black text-emerald-700">
                                <UserRound className="h-4 w-4" />
                                {member.relationship_label}
                              </p>

                              <h3 className="text-lg font-black text-slate-900">
                                {member.profile?.full_name || 'Unknown member'}
                              </h3>

                              <p className="mt-1 flex flex-wrap items-center gap-2 text-sm font-semibold text-slate-500">
                                <Phone className="h-4 w-4" />
                                {member.profile?.phone || 'No phone'}
                                <span>•</span>
                                Position{' '}
                                {member.position_number ||
                                  member.payout_order ||
                                  'N/A'}
                              </p>
                            </div>

                            <div className="flex flex-wrap gap-2">
                              <StatusPill status={member.status} />
                              <StatusPill
                                status={member.profile?.verification_status}
                              />
                            </div>
                          </div>

                          <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                            <DetailBox
                              label="Amount Due"
                              value={formatCurrency(
                                contribution?.amount_due ||
                                  member.contribution_amount ||
                                  fundSpace?.contribution_amount
                              )}
                            />

                            <DetailBox
                              label="Amount Paid"
                              value={formatCurrency(contribution?.amount_paid)}
                            />

                            <DetailBox
                              label="Payment Status"
                              value={formatLabel(contribution?.status)}
                            />

                            <DetailBox
                              label="Payment Timing"
                              value={formatLabel(contribution?.payment_timing)}
                            />

                            <DetailBox
                              label="Paid At"
                              value={formatDateTime(contribution?.paid_at)}
                            />

                            <DetailBox
                              label="Late Fee"
                              value={formatCurrency(lateFeeAmount)}
                            />

                            <DetailBox
                              label="Late Fee Status"
                              value={formatLabel(
                                contribution?.late_fee_status
                              )}
                            />

                            <DetailBox
                              label="Reference"
                              value={
                                contribution?.payment_reference || 'Not set'
                              }
                            />
                          </div>

                          {contribution?.late_fee_waiver_reason && (
                            <div className="mt-4 rounded-2xl border border-emerald-100 bg-emerald-50 p-4 text-emerald-700">
                              <p className="text-xs font-black uppercase tracking-wide">
                                Late Fee Waiver Reason
                              </p>
                              <p className="mt-2 text-sm font-semibold leading-6">
                                {contribution.late_fee_waiver_reason}
                              </p>
                            </div>
                          )}
                        </div>

                        <div className="rounded-3xl border border-slate-200 bg-white p-4">
                          <p className="mb-3 text-sm font-black text-slate-900">
                            Payment Action
                          </p>

                          {contribution ? (
                            <>
                              <button
                                type="button"
                                disabled={!canPay}
                                onClick={() =>
                                  openPaymentModal(member, contribution)
                                }
                                className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-emerald-700 px-4 text-sm font-black text-white hover:bg-emerald-800 disabled:cursor-not-allowed disabled:opacity-50"
                              >
                                <Smartphone className="h-4 w-4" />
                                {canPay ? 'Pay with MoMo' : 'Payment Submitted'}
                              </button>

                              {!canPay && (
                                <p className="mt-3 text-xs font-semibold leading-5 text-slate-500">
                                  This contribution is not open for manual
                                  payment. If it is pending admin review, wait
                                  for admin approval.
                                </p>
                              )}
                            </>
                          ) : (
                            <p className="rounded-2xl bg-amber-50 p-4 text-sm font-bold leading-6 text-amber-700">
                              No contribution record found for this round.
                            </p>
                          )}

                          {member.payouts.length > 0 && (
                            <div className="mt-4 rounded-2xl bg-slate-50 p-4">
                              <p className="text-xs font-black uppercase tracking-wide text-slate-400">
                                Latest Payout
                              </p>
                              <p className="mt-1 text-sm font-black text-slate-900">
                                {formatCurrency(member.payouts[0]?.net_amount)}
                              </p>
                              <p className="mt-1 text-xs font-semibold text-slate-500">
                                {formatLabel(member.payouts[0]?.status)} •{' '}
                                {formatDate(member.payouts[0]?.paid_at)}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </article>
                  );
                })}
            </div>
          )}
        </section>

        <section className="grid gap-5 lg:grid-cols-2">
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-4 flex items-start gap-3">
              <div className="rounded-2xl bg-emerald-50 p-3 text-emerald-700">
                <HandCoins className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-lg font-black text-slate-900">
                  Current Payout Recipient
                </h2>
                <p className="mt-1 text-sm leading-6 text-slate-500">
                  Member expected to receive payout for the selected round.
                </p>
              </div>
            </div>

            {currentRecipient ? (
              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="text-lg font-black text-slate-900">
                  {currentRecipient.profile?.full_name || 'Unknown recipient'}
                </p>
                <p className="mt-1 text-sm font-semibold text-slate-500">
                  {currentRecipient.profile?.phone || 'No phone'} • Position{' '}
                  {currentRecipient.position_number ||
                    currentRecipient.payout_order ||
                    'N/A'}
                </p>
              </div>
            ) : (
              <p className="rounded-2xl bg-slate-50 p-4 text-sm font-bold text-slate-500">
                No payout recipient is set for this round.
              </p>
            )}
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-4 flex items-start gap-3">
              <div className="rounded-2xl bg-emerald-50 p-3 text-emerald-700">
                <CircleDollarSign className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-lg font-black text-slate-900">
                  Collection Summary
                </h2>
                <p className="mt-1 text-sm leading-6 text-slate-500">
                  Selected round collection progress.
                </p>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <DetailBox
                label="Expected"
                value={formatCurrency(stats.expectedAmount)}
              />
              <DetailBox
                label="Collected"
                value={formatCurrency(stats.collectedAmount)}
              />
              <DetailBox label="Paid Members" value={stats.paid} />
              <DetailBox label="Pending Members" value={stats.pending} />
            </div>
          </div>
        </section>
      </div>

      {selectedContribution && (
        <ManualMerchantPaymentModal
          open={paymentModalOpen}
          onClose={() => {
            setPaymentModalOpen(false);
            setSelectedContribution(null);
            setSelectedCustomerName('');
          }}
          onSubmitted={handleSubmittedPayment}
          contributionId={selectedContribution.id}
          customerName={selectedCustomerName}
          amountDue={Number(selectedContribution.amount_due || 0)}
          title="Submit Fund Space Contribution"
        />
      )}
    </main>
  );
}